
/**
 * @brief The DirectoryReaderSync interface of the File System API lets you read the entries in a directory.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/DirectoryReaderSync
 */
function DirectoryReaderSync() {

}

