
/**
 * @brief The ErrorEvent interface represents events providing information related to errors in scripts or in files.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/ErrorEvent
 */
function ErrorEvent() {

}

