#!/bin/bash
git archive --format zip --output ..\Runtime\codelite-icons.zip master
