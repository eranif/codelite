
/**
 * @brief A CSSRuleList is an array-like object containing an ordered collection of CSSRule objects.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/CSSRuleList
 */
function CSSRuleList() {

}

