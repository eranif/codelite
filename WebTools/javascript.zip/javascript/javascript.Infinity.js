
/**
 * @brief The global Infinity property is a numeric value representing infinity.
 * @link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Infinity
 */
function Infinity() {

}

