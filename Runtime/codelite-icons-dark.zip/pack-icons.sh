#!/bin/bash

git archive --format zip --output ..\codelite-icons-dark.zip master
