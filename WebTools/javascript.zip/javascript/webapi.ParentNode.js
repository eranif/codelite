
/**
 * @brief The ParentNode interface contains methods that are particular to Node objects that can have children.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/ParentNode
 */
function ParentNode() {

}

