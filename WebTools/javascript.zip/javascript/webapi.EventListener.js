
/**
 * @brief This method is called whenever an event occurs of the type for which the EventListener interface was registered.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/EventListener
 */
function EventListener() {

}

