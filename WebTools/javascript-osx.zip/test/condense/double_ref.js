var a = {an: "object"};
var b = a;
