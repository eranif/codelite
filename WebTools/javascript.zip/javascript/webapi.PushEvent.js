
/**
 * @brief Doesn't implement any specific properties, but inherits properties from its parent, ExtendableEvent.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/PushEvent
 */
function PushEvent() {

}

