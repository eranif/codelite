
/**
 * @brief The CSSCounterStyleRule interface represents …
 * @link https://developer.mozilla.org/en-US/docs/Web/API/CSSCounterStyleRule
 */
function CSSCounterStyleRule() {

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/CSSCounterStyleRule/name
	 */
	this.name = '';

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/CSSCounterStyleRule/system
	 */
	this.system = '';

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/CSSCounterStyleRule/symbols
	 */
	this.symbols = '';

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/CSSCounterStyleRule/additiveSymbols
	 */
	this.additiveSymbols = '';

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/CSSCounterStyleRule/negative
	 */
	this.negative = '';

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/CSSCounterStyleRule/prefix
	 */
	this.prefix = '';

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/CSSCounterStyleRule/suffix
	 */
	this.suffix = '';

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/CSSCounterStyleRule/range
	 */
	this.range = '';

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/CSSCounterStyleRule/pad
	 */
	this.pad = '';

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/CSSCounterStyleRule/speakAs
	 */
	this.speakAs = '';

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/CSSCounterStyleRule/fallback
	 */
	this.fallback = '';

}

