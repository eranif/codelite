<?php

// Start of ereg v.

/**
 * @param pattern
 * @param string
 * @param registers[optional]
 */
function ereg ($pattern, $string, &$registers) {}

/**
 * @param pattern
 * @param replacement
 * @param string
 */
function ereg_replace ($pattern, $replacement, $string) {}

/**
 * @param pattern
 * @param string
 * @param registers[optional]
 */
function eregi ($pattern, $string, &$registers) {}

/**
 * @param pattern
 * @param replacement
 * @param string
 */
function eregi_replace ($pattern, $replacement, $string) {}

/**
 * @param pattern
 * @param string
 * @param limit[optional]
 */
function split ($pattern, $string, $limit) {}

/**
 * @param pattern
 * @param string
 * @param limit[optional]
 */
function spliti ($pattern, $string, $limit) {}

/**
 * @param string
 */
function sql_regcase ($string) {}

// End of ereg v.
?>
