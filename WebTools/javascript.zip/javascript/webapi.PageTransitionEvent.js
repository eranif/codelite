
/**
 * @brief Page transition events fire when a webpage is being loaded or unloaded.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/PageTransitionEvent
 */
function PageTransitionEvent() {

}

