<?php

namespace parallel;

class Error extends \Error {}
