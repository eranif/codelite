
/**
 * @brief The DOM MozSmsMessage object represents an SMS text message and has all the information about sender, recipient, body text and date of the message itself.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/MozSmsMessage
 */
function MozSmsMessage() {

}

