
/**
 * @brief The DOMError interface describes an error object that contains an error name.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/DOMError
 */
function DOMError() {

}

