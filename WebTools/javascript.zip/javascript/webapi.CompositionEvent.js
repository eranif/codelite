
/**
 * @brief The DOM CompositionEvent represents events that occur due to the user indirectly entering text.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/CompositionEvent
 */
function CompositionEvent() {

}

