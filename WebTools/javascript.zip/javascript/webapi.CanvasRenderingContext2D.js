
/**
 * @brief To get an object of this interface, call getContext() on a &lt;canvas>, supplying "2d" as the argument:
 * @link https://developer.mozilla.org/en-US/docs/Web/API/CanvasRenderingContext2D
 */
function CanvasRenderingContext2D() {

}

