<?php

/**
 * The PHPStorm meta file for Pest.
 */

namespace PHPSTORM_META {
    override(\expect(0), type(0));
}