<?php

namespace parallel\Runtime\Error;

use parallel\Runtime\Error;

class Bootstrap extends Error {}
