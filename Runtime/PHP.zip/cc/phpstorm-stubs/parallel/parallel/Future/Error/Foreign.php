<?php

namespace parallel\Future\Error;

use parallel\Error;

class Foreign extends Error {}
