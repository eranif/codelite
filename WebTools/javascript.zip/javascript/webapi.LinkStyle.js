
/**
 * @brief The LinkStyle interface allows to access the associated CSS style sheet of a node.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/LinkStyle
 */
function LinkStyle() {

}

