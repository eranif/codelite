
/**
 * @brief Technical review completed.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/MozMmsMessage
 */
function MozMmsMessage() {

}

