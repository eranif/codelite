
/**
 * @brief Point represents a 2D point.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/Point
 */
function Point() {

}

