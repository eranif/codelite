
/**
 * @brief The list below includes the properties inherited from its parent, Event.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/AudioProcessingEvent
 */
function AudioProcessingEvent() {

}

