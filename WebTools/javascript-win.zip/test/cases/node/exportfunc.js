var f = module.exports = function(a, b) {
  return a + b;
};

f(1, 2);
