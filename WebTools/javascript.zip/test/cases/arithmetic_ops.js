
var a = '1' + 1;
a; //: string

var b = '1' - 1;
b; //: number

var c = '1' * 1;
c; //: number

var d = '1' / 1;
d; //: number

var e = '1' % 1;
e; //: number

var f = '1' ** 1;
f; //: number
