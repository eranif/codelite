
/**
 * @brief ArrayBufferView is a helper type representing any of the following JavaScript TypedArray types:
 * @link https://developer.mozilla.org/en-US/docs/Web/API/ArrayBufferView
 */
function ArrayBufferView() {

}

