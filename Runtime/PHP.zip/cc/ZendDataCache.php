<?php

// Start of Zend Data Cache v.

function zend_shm_cache_store () {}

function zend_shm_cache_fetch () {}

function zend_shm_cache_delete () {}

function zend_shm_cache_clear () {}

function zend_disk_cache_store () {}

function zend_disk_cache_fetch () {}

function zend_disk_cache_delete () {}

function zend_disk_cache_clear () {}

// End of Zend Data Cache v.
?>
