try {
  foo();
} catch(e) {
  e.message; //doc: A human-readable description of the error.
}
e //: ?
