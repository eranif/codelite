
/**
 * @brief The NavigatorOnLine interface contains methods and properties related to the connectivity status of the browser.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/NavigatorOnLine
 */
function NavigatorOnLine() {

}

