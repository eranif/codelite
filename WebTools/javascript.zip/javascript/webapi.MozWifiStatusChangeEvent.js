
/**
 * @brief The MozWifiStatusChangeEvent interface provides developers with information regarding the current status of the Wifi connection.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/MozWifiStatusChangeEvent
 */
function MozWifiStatusChangeEvent() {

}

