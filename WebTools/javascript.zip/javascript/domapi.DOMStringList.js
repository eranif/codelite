
/**
 * @brief A type returned by some APIs which contains a list of DOMString (strings).
 * @link https://developer.mozilla.orghttps://developer.mozilla.org/en-US/docs/Web/API/DOMStringList
 */
function DOMStringList() {

}

