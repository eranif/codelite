export default 22

export function hello() { return true }
