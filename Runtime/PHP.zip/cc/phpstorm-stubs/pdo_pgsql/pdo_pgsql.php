<?php

// Start of pdo_pgsql v.1.0.2
// End of pdo_pgsql v.1.0.2
