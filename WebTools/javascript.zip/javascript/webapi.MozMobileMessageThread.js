
/**
 * @brief The DOM MozMobileMessageThread object represents a thread of messages.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/MozMobileMessageThread
 */
function MozMobileMessageThread() {

}

