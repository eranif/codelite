function x(a) {}
function y() { if (something) return true; else return 100; }

x("hi");
x([10]);
y();
