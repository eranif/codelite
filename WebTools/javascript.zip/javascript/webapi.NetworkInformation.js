
/**
 * @brief The NetworkInformation interface contains methods and properties related to the network type of the browser.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/NetworkInformation
 */
function NetworkInformation() {

}

