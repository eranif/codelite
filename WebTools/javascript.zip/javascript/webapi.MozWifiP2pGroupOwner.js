
/**
 * @brief The MozWifiP2pGroupOwner is an interface that represents the group owner of WiFi Direct connection.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/MozWifiP2pGroupOwner
 */
function MozWifiP2pGroupOwner() {

}

