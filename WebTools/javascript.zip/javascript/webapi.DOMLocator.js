
/**
 * @brief Indicates a location such as where an error occurred. Returned by DOMError.location.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/DOMLocator
 */
function DOMLocator() {

}

