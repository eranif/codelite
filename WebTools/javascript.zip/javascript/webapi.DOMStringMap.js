
/**
 * @brief Used by the dataset HTML attribute to represent data for custom attributes added to elements.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/DOMStringMap
 */
function DOMStringMap() {

}

