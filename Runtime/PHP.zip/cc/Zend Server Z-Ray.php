<?php

// Start of Zend Server Z-Ray v.7.0.0

class ZRayExtension  {

	public function ZRayExtension () {}

	public function traceFunction () {}

	public function hasTraceFunction () {}

	public function traceFile () {}

	public function setEnabledAfter () {}

	public function setEnabled () {}

	public function isEnabled () {}

	public function getMetadata () {}

	public function setMetadata () {}

}

function zray_disable () {}

function zend_apm_disable () {}

function zend_apm_set_request_context () {}

function zray_get_loaded_extensions () {}

// End of Zend Server Z-Ray v.7.0.0
?>
