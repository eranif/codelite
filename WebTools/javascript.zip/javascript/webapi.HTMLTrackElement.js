
/**
 * @brief The HTMLTrackElement interface provides access to the properties of &lt;track> elements, as well as methods to manipulate them.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/HTMLTrackElement
 */
function HTMLTrackElement() {

}

