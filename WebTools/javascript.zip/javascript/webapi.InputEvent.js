
/**
 * @brief The InputEvent interface represents an event notifying of editable content change.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/InputEvent
 */
function InputEvent() {

}

