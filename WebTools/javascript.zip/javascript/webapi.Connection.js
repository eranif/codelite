
/**
 * @brief The Connection interface represents the connectivity of the device on which the browser runs.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/Connection
 */
function Connection() {

}

