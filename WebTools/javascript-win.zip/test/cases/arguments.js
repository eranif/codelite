var arguments = 1; //: number

(function() { return arguments.length; })(); //: number
