
/**
 * @brief An event handler for the popstate event on the window.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/PopStateEvent
 */
function PopStateEvent() {

}

