<?php

// Start of apc v.

/**
 * @param "key"
 * @param "success"
 */
function apc_fetch ($"key", &$"success") {}

function apc_store () {}

function apc_add () {}

function apc_delete () {}

function apc_cache_info () {}

function apc_clear_cache () {}

function apc_define_constants () {}

function apc_load_constants () {}

function apc_sma_info () {}

function apc_compile_file () {}

function apc_bin_dump () {}

function apc_bin_dumpfile () {}

function apc_bin_load () {}

function apc_bin_loadfile () {}

function apc_cas () {}

function apc_dec () {}

function apc_delete_file () {}

function apc_exists () {}

function apc_inc () {}

// End of apc v.
?>
