
/**
 * @brief The ElementTraversal interface was defining methods allowing to access from one Node to another one in the document tree.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/ElementTraversal
 */
function ElementTraversal() {

}

