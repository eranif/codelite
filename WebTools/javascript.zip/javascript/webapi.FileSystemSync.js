
/**
 * @brief In the File System API, a FileSystemSync object represents a file system. It has two properties.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/FileSystemSync
 */
function FileSystemSync() {

}

