
/**
 * @brief The BluetoothDeviceEvent API provides access to a Bluetooth device when the devicefound event is fired. See BluetoothAdapter.ondevicefound for more information.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/BluetoothDeviceEvent
 */
function BluetoothDeviceEvent() {

}

