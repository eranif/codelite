
/**
 * @brief The HTMLMetaElement interface contains descriptive metadata about a document. Itt inherits all of the properties and methods described in the HTMLElement interface.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/HTMLMetaElement
 */
function HTMLMetaElement() {

}

