var x = "foo".match(/o/) || []

x //: [string]
