
/**
 * @brief The FileEntrySync interface of the File System API represents a file in a file system. It lets you write content to a file.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/FileEntrySync
 */
function FileEntrySync() {

}

