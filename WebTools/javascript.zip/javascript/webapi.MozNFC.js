
/**
 * @brief MozNFC is the top level API for operating in NFC Reader/Writer mode, NFC P2P mode and NFC Card Emulation mode.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/MozNFC
 */
function MozNFC() {

}

