// environment=browser
// environment=jquery

$("#foo").blur().click(function(e) {
  e; //: jQuery.Event
  e.pageX; //: number
});
