
/**
 * @brief NavigatorGeolocation  contains a creation method allowing objects implementing it to obtain a Geolocation instance.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/NavigatorGeolocation
 */
function NavigatorGeolocation() {

}

