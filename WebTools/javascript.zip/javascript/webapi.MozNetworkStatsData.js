
/**
 * @brief The MozNetworkStatsData objects represent a chunk of data usage statistics.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/MozNetworkStatsData
 */
function MozNetworkStatsData() {

}

