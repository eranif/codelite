<?php

$_COOKIE = array();
$_ENV = array();
$_FILES = array();
$_GET = array();
$_POST = array();
$_REQUEST = array();
$_SERVER = array();
$_SESSION = array();
$GLOBALS = array();

