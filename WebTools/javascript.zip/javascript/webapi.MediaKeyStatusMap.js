
/**
 * @brief TBD
 * @link https://developer.mozilla.org/en-US/docs/Web/API/MediaKeyStatusMap
 */
function MediaKeyStatusMap() {

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/MediaKeyStatusMap/entries
	 */
	this.entries = function() {};

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/MediaKeyStatusMap/forEach
	 */
	this.ediaKeyStatusMap.forEach(callback[', argument'])

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/MediaKeyStatusMap/get
	 */
	this.get = function() {};

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/MediaKeyStatusMap/has
	 */
	this.has = function() {};

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/MediaKeyStatusMap/keys
	 */
	this.keys = function() {};

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/MediaKeyStatusMap/values
	 */
	this.values = function() {};

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/MediaKeyStatusMap/[@@iterator]
	 */
	this.['@@iterator'] = function() {};

}

