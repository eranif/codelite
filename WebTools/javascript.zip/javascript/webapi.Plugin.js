
/**
 * @brief The Plugin interface provides information about a browser plugin.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/Plugin
 */
function Plugin() {

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/Plugin/item
	 */
	this.item = '';

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/Plugin/namedItem
	 */
	this.namedItem = '';

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/Plugin/item
	 */
	this.lugin.item

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/Plugin/namedItem
	 */
	this.lugin.namedItem

}

