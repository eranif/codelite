
/**
 * @brief Represents an error that occurs while using the FileReader interface.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/FileError
 */
function FileError() {

}

