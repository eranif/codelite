
/**
 * @brief The drag event is fired when an element or text selection is being dragged (every few hundred milliseconds).
 * @link https://developer.mozilla.org/en-US/docs/Web/API/DragEvent
 */
function DragEvent() {

}

