
/**
 * @brief Inherits properties from its parent, AudioNode.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/DynamicsCompressorNode
 */
function DynamicsCompressorNode() {

}

