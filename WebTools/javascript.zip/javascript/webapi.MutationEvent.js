
/**
 * @brief Provides event properties that are specific to modifications to the Document Object Model (DOM) hierarchy and nodes.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/MutationEvent
 */
function MutationEvent() {

}

