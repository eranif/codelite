<?php

// Start of ctype v.

/**
 * @param text
 */
function ctype_alnum ($text) {}

/**
 * @param text
 */
function ctype_alpha ($text) {}

/**
 * @param text
 */
function ctype_cntrl ($text) {}

/**
 * @param text
 */
function ctype_digit ($text) {}

/**
 * @param text
 */
function ctype_lower ($text) {}

/**
 * @param text
 */
function ctype_graph ($text) {}

/**
 * @param text
 */
function ctype_print ($text) {}

/**
 * @param text
 */
function ctype_punct ($text) {}

/**
 * @param text
 */
function ctype_space ($text) {}

/**
 * @param text
 */
function ctype_upper ($text) {}

/**
 * @param text
 */
function ctype_xdigit ($text) {}

// End of ctype v.
?>
