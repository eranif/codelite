
/**
 * @brief The MouseWheelEvent interface represents events that occur due to the user turning a mouse wheel.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/MouseWheelEvent
 */
function MouseWheelEvent() {

}

