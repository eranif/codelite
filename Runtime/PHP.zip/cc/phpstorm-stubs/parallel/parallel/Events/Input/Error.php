<?php

namespace parallel\Events\Input;

class Error extends \parallel\Error {}
