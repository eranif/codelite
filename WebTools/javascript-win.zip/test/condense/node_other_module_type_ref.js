exports.b = require('./node_export_function_a').a;
