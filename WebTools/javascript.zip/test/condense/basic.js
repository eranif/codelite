var x = 10;
var y = {
  foo: 20,
  bar: "hi";
};
