<?php

namespace MongoDB\Driver\Exception;

class WriteConcernException extends RuntimeException implements Exception {}
