<?php

namespace parallel\Events\Error;

use parallel\Events\Error;

class Existence extends Error {}
