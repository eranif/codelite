export default class {
  methodA() {
  }
};