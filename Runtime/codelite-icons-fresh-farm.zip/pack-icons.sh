#!/bin/bash
git archive --format zip --output ../Runtime/codelite-icons-fresh-farm.zip master
