
/**
 * @brief The parseInt() function parses a string argument and returns an integer of the specified radix (the base in mathematical numeral systems).
 * @link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/parseInt
 */
function parseInt()() {

}

