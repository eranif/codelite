
/**
 * @brief NavigatorLanguage contains methods and properties related to the language of the navigator.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/NavigatorLanguage
 */
function NavigatorLanguage() {

}

