
/**
 * @brief The CameraControl.capabilities property returns a CameraCapabilities object, which describes all the camera's capabilities.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/CameraCapabilities
 */
function CameraCapabilities() {

}

