
/**
 * @brief The MozWifiConnectionInfoEvent interface provides developers with information regarding the state of the current Wifi connection.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/MozWifiConnectionInfoEvent
 */
function MozWifiConnectionInfoEvent() {

}

