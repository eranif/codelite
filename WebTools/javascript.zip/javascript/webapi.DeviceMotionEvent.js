
/**
 * @brief The DeviceMotionEvent provides web developers with information about the speed of changes for the device's position and orientation.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/DeviceMotionEvent
 */
function DeviceMotionEvent() {

}

