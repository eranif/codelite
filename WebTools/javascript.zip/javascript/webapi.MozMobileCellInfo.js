
/**
 * @brief The MozMobileCellInfo interface allow to access to cell location information.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/MozMobileCellInfo
 */
function MozMobileCellInfo() {

}

