
/**
 * @brief The DOM CallEvent represents events related to telephone calls.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/CallEvent
 */
function CallEvent() {

}

