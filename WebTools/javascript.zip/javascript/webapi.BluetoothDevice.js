
/**
 * @brief The BluetoothDevice API provides information regarding a given Bluetooth device.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/BluetoothDevice
 */
function BluetoothDevice() {

}

