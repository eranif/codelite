
/**
 * @brief A DeviceRotationRate object provides information about the rate at which the device is rotating around all three axes.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/DeviceRotationRate
 */
function DeviceRotationRate() {

}

