
/**
 * @brief The MozVoicemailStatus API provides access to a voicemail status.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/MozVoicemailStatus
 */
function MozVoicemailStatus() {

}

