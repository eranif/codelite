#!/bin/bash

git archive --format zip --output ../Runtime/codelite-icons-dark.zip master
