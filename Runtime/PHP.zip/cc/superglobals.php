<?php

define ('$_FILES', "");
define('$_ENV', "");
define('$_FILES', "");
define('$_GET', "");
define('$_POST', "");
define('$_REQUEST', ""); 
define('$_SERVER', ""); 
define('$_SESSION', "");
define('$GLOBALS', "");
define('$_COOKIE', "");

?>
