module.exports = {index: true}
