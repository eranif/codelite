
/**
 * @brief The AnimationEvent interface represents events providing information related to animations.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/AnimationEvent
 */
function AnimationEvent() {

}

