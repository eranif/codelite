
/**
 * @brief 
 * @link https://developer.mozilla.org/en-US/docs/Web/API/MediaKeySystemAccess
 */
function MediaKeySystemAccess() {

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/MediaKeySystemAccess/createMediaKeys
	 */
	this.createMediaKeys = function() {};

	/**
	 * @brief The documentation about this has not yet been written; please consider contributing!
	 * @link https://developer.mozilla.org/en-US/docs/Web/API/MediaKeySystemAccess/getConfiguration
	 */
	this.getConfiguration = function() {};

}

