
/**
 * @brief The FileReaderSync interface allows to read File or Blob objects in a synchronous way.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/FileReaderSync
 */
function FileReaderSync() {

}

