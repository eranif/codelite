
/**
 * @brief The MozNetworkStats object gives access to statistics about the data usage for a given network.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/MozNetworkStats
 */
function MozNetworkStats() {

}

