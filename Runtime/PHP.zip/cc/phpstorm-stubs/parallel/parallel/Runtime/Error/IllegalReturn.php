<?php

namespace parallel\Runtime\Error;

use parallel\Runtime\Error;

class IllegalReturn extends Error {}
