
/**
 * @brief The MozActivityOptions interface allows apps to declare the activity they want to create and also to access information of activities they want to handle.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/MozActivityOptions
 */
function MozActivityOptions() {

}

