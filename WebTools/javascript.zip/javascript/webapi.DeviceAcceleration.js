
/**
 * @brief A DeviceAcceleration object provides information about the amount of acceleration the device is experiencing along all three axes.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/DeviceAcceleration
 */
function DeviceAcceleration() {

}

