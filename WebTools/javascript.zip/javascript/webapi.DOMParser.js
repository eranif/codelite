
/**
 * @brief DOMParser can parse XML or HTML source stored in a string into a DOM Document. DOMParser is specified in DOM Parsing and Serialization.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/DOMParser
 */
function DOMParser() {

}

