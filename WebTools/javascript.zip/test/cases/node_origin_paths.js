// plugin=node

require('./node/localfile').hello; //origin: node/localfile.js
