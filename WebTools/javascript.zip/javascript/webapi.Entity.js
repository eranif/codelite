
/**
 * @brief Read-only reference to a DTD entity. Also inherits the methods and properties of Node.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/Entity
 */
function Entity() {

}

