
/**
 * @brief 
 * @link https://developer.mozilla.org/en-US/docs/Web/API/ChannelMergerNode
 */
function ChannelMergerNode() {

}

