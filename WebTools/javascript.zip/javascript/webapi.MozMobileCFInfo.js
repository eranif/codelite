
/**
 * @brief The MozMobileCFInfo interface defines options used to retrieve or define call forwarding settings.
 * @link https://developer.mozilla.org/en-US/docs/Web/API/MozMobileCFInfo
 */
function MozMobileCFInfo() {

}

